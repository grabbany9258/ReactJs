function Footer(props) {
  return (
    <div className="mt-5 p-4 bg-dark text-white text-center">
      <p>{props.copyright}</p>
    </div>
  );
}
export default Footer;
