import React from 'react';

function Home() {
  return (
    <div>
      <h1>Applicaiton</h1>
      <h2>Home Page</h2>
    </div>
  );
}

export default Home;
