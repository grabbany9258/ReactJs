import React from 'react';

function Preferences() {
  return (
    <div>
      <h1>Preferences</h1>
      <p>lorem</p>
    </div>
  );
}

export default Preferences;
